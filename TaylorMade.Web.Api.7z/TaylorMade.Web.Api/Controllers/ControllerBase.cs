﻿using Microsoft.AspNetCore.Mvc;

namespace TaylorMade.Web.Api.Controllers
{
    public class ControllerBase : Controller
    {
    }
}
